

const DATA = [
  { title: "iMessage Preview Problems ", height: 150 },
  { title: "iMessage Preview Problems; leak your location by ", height: 250 },
  { title: "iMessage Preview Problems ", height: 150 },
  { title: "iMessage Preview Problems; leak your location by ", height: 250 },
  { title: "iMessage Preview Problems ", height: 150 },

  { title: "iMessage Preview Problems; leak your location by ", height: 250 },
  { title: "iMessage Preview Problems ", height: 150 },
  { title: "iMessage Preview Problems; leak your location by ", height: 250 },
  { title: "iMessage Preview Problems ", height: 150 },
  { title: "iMessage Preview Problems; leak your location by ", height: 250 },
  
  { title: "iMessage Preview Problems ", height: 150 },
  { title: "iMessage Preview Problems; leak your location by ", height: 250 },
  { title: "iMessage Preview Problems; leak your location by ", height: 250 },
  { title: "iMessage Preview Problems ", height: 150 },
  { title: "iMessage Preview Problems; leak your location by ", height: 250 },
  { title: "iMessage Preview Problems ", height: 150 },
  { title: "iMessage Preview Problems; leak your location by ", height: 250 },
  { title: "iMessage Preview Problems ", height: 150 },
  { title: "iMessage Preview Problems; leak your location by ", height: 250 },
  { title: "iMessage Preview Problems ", height: 150 },
  { title: "iMessage Preview Problems; leak your location by ", height: 250 }

];

class Box {
  constructor(parent, css, content) {
    this.height = 0;
    this.width = 0;
    this._parent = parent;
    parent.append("<div class='" + css + "'>" + content + "</div>");
    this.el = parent.children(":last");
    this.move(0, 0);
    this.setHeight(0);
    this.setWidth(0);
  }
  move(x, y) {
    this.x = x;
    this.y = y;
    this.el.animate({ top: x + "px", left: y + "px" }, 0);
  }
  setHeight(height) {
    this.height = height;
    this.el.height(height);
  }

  setWidth(width) {
    this.width = width;
    this.el.width(width);
  }

}

function renderLayout(data) {
  $("#main").empty();
  let bWidth = ($(window).width() / 4 | 0) - 20;
  let columnSize = data.length / 4 | 0;
  let bigColumns = data.length % 4;
  let currentX = [0, 0, 0, 0];
  let column = -1;
  let currentIndexInColumn = 0;

  let mainBox = new Box($("#main"), "mainBox", "");
  mainBox.move(0, 0);
  mainBox.setWidth($(window).width());

  data.forEach((d, i) => {
    column++;
    if (column === 4)
      column = 0;
    let box = new Box(mainBox.el, "box", d.title);
    d.height = d.height;
    box.move(currentX[column] + 20, column * (bWidth + 10));
    box.setWidth(bWidth);
    box.setHeight(d.height);
    currentX[column] += d.height + 20;

  });

}

$("#search").click(function (e) {
  e.preventDefault();
  let data = DATA.filter((el)=> { return el.title.indexOf($("#text").val()) > -1; });
  renderLayout(data);
});

renderLayout(DATA);